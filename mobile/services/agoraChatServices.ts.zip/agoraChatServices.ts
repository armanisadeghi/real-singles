import { getAgoraChatToken } from "@/lib/api";
import {
  ChatClient,
  ChatConversationType,
  ChatGroupStyle,
  ChatMessage,
  ChatMessageChatType,
  ChatOptions,
} from "react-native-agora-chat";

// const appKey = "411355696#1562220"; // Use your actual app key
const appKey = "611349722#1555844";
// const chatClient = ChatClient.getInstance();
export const chatClient = ChatClient.getInstance();

// Track initialization and login state
let isInitialized = false;
let isLoggedIn = false;
let currentUserId: string | null = null;

export const initChat = async () => {
  if (isInitialized) {
    console.log("Chat already initialized");
    return chatClient;
  }

  const options = new ChatOptions({
    appKey,
    autoLogin: false,
  });
  console.log("Initializing Agora Chat with options:", options);

  await chatClient.init(options);
  isInitialized = true;
  console.log("Agora Chat initialized successfully");

  // Add connection listeners
  chatClient.addConnectionListener({
    onTokenWillExpire() {
      console.log("Token will expire");
      // You should refresh the token here
    },
    onTokenDidExpire() {
      console.log("Token expired");
      // You should refresh the token here
    },
    onConnected() {
      console.log("Connected to chat");
    },
    onDisconnected() {
      console.log("Disconnected from chat");
      isLoggedIn = false;
      currentUserId = null;
    },
  });

  return chatClient;
};




export const loginToChat = async (userId: string, token: string) => {
  console.log("userId in loginToChat:",userId);
  console.log("token in loginToChat::",token);
  
  // If already logged in as the same user, skip
  if (isLoggedIn && currentUserId === userId) {
    console.log("Already logged in as", userId);
    return { success: true };
  }

  try {
    const res = await chatClient.loginWithToken(userId, token);
    console.log("Login successful:", res);
    isLoggedIn = true;
    currentUserId = userId;
    return res;
  } catch (error: any) {
    // Check if error is "already logged in" (code 200) - this is actually success
    if (error?.code === 200 && error?.description?.includes("already logged in")) {
      console.log("User already logged in - treating as success");
      isLoggedIn = true;
      currentUserId = userId;
      return { success: true, code: 200, description: error.description };
    }
    
    // For other errors, log and return
    console.error("Error in loginToChat:", error);
    isLoggedIn = false;
    currentUserId = null;
    throw error; // Throw actual errors instead of returning them
  }
};

// services/agoraChatServices.ts - Updated

let currentLoginUserId: string | null = null;

export const ensureChatLogin = async (userId: string) => {
  // If already logged in as this user
  if (currentLoginUserId === userId && isChatLoggedIn()) {
    console.log(`Already logged in as ${userId}`);
    return true;
  }
  
  // If logged in as a different user, logout first
  if (currentLoginUserId && currentLoginUserId !== userId) {
    console.log(`Logging out previous user ${currentLoginUserId}`);
    await logoutFromChat();
  }
  
  // Get new token and login
  const tokenRes = await getAgoraChatToken(userId);
  await initChat(); // This should be idempotent
  await loginToChat(userId, tokenRes.data.userToken);
  currentLoginUserId = userId;
  return true;
};

export const logoutFromChat = async () => {
  try {
    if (chatClient && isChatLoggedIn()) {
      await chatClient.logout();
    }
  } finally {
    currentLoginUserId = null;
    isLoggedIn = false;
  }
};

// export const logoutFromChat = async () => {
//   try {
//     // Clear all conversations & messages
//     await chatClient.chatManager.deleteAllConversations(true);
    
//     await chatClient.logout();
//   } finally {
//     isLoggedIn = false;
//     currentUserId = null;
//   }
// };



export const isChatInitialized = () => {
  return isInitialized;
};

export const isChatLoggedIn = () => {
  return isLoggedIn;
};

export const getCurrentChatUserId = () => {
  return currentUserId;
};

export const sendMessage = async (toUserId: string, text: string) => {
  const message = ChatMessage.createTextMessage(
    toUserId,
    text,
    ChatMessageChatType.PeerChat
  );
  
  console.log("Sending message to:", toUserId, "text:", text);
  
  const result = await chatClient.chatManager.sendMessage(message);
  console.log("Message sent successfully:", result);
  
  return result;
};

export const sendCustomMessage = async (
  toUserId: string,
  event: string,
  params: { [key: string]: string }
) => {
  const message = ChatMessage.createCustomMessage(
    toUserId,
    event,
    ChatMessageChatType.PeerChat,
    { params }
  );
  return chatClient.chatManager.sendMessage(message);
};

export const setupMessageListener = (
  callback: (messages: ChatMessage[]) => void
) => {
  const listener = {
    onMessagesReceived: (messages: ChatMessage[]) => {
      callback(messages);
    },
  };

  chatClient.chatManager.addMessageListener(listener);

  // Return a function to remove this listener
  return () => {
    chatClient.chatManager.removeMessageListener(listener);
  };
};



export const getAllConversations = async () => {
  try {
    const conversations = await chatClient.chatManager.getAllConversations();
    console.log("conversations:", conversations);
    return conversations;
  } catch (error) {
    console.log("error in getAllConversations", error);
    return error;
  }
};

export const getUserHistoryMessages = async (
  userId: string,
  pageSize: number = 20,
  startMsgId: string = ""
) => {
  // fetchHistoryMessages(convId, convType, pageSize, startMsgId?)
  const result = await (chatClient.chatManager.fetchHistoryMessages as any)(
    userId,
    ChatConversationType.PeerChat,
    pageSize,
    startMsgId || undefined
  );
  return result.list || [];
};

export const getGroupHistoryMessages = async (
  groupId: string,
  pageSize: number = 20,
  startMsgId: string = ""
) => {
  console.log("groupId", groupId);

  const result = await (chatClient.chatManager.fetchHistoryMessages as any)(
    groupId,
    ChatConversationType.GroupChat,
    pageSize,
    startMsgId || undefined
  );
  console.log("result", result);

  return result.list || [];
};

// export const sendGroupMessage = async (groupId: string, text: string) => {
//   const message = ChatMessage.createTextMessage(
//     groupId,
//     text,
//     ChatMessageChatType.GroupChat
//   );
//   return chatClient.chatManager.sendMessage(message);
// };

// In agoraChatServices.ts
export const sendGroupMessage = async (groupId: string, text: string) => {
  try {
    const message = ChatMessage.createTextMessage(
      groupId,
      text,
      ChatMessageChatType.GroupChat
    );
    
    console.log("Sending group message to:", groupId, "text:", text);
    
    const result = await chatClient.chatManager.sendMessage(message);
    console.log("Group message sent successfully:", result);
    
    return result;
  } catch (error) {
    console.error("Error sending group message:", error);
    throw error;
  }
};
// export const sendGroupMessage = async (
//   groupId: string,
//   text: string
// ): Promise<any> => {
//   return new Promise((resolve, reject) => {
//     // ✅ Correct argument order: targetId first, then text
//     const msg = ChatMessage.createTextMessage(
//       groupId,
//       text,
//       ChatMessageChatType.GroupChat
//     );

//     chatClient.chatManager.sendMessage(msg, {
//       onSuccess: (message) => {
//         console.log("✅ Message sent successfully:", message);
//         resolve(message);
//       },
//       onError: (error) => {
//         console.log("❌ Message send failed:", error);
//         reject(error);
//       },
//     });
//   });
// };


export interface AgoraGroupOptions {
   groupId?: string; // 🆕 Allow custom ID
  groupName: string;
  desc?: string;
  owner: string;
  members?: string[];
  maxCount?: number;
  style?: ChatGroupStyle;
}


// export const createAgoraGroup = async ({
//   groupId, // 🆕 Custom ID parameter
//   groupName,
//   desc = "",
//   owner,
//   members = [],
//   maxCount = 200,
//   style = ChatGroupStyle.PrivateOnlyOwnerInvite,
// }: AgoraGroupOptions) => {
//   try {
//     const finalMembers = members.filter(id => id !== owner);

//     // 🚀 Use custom groupId if provided, otherwise let Agora generate
//     const groupData: any = {
//       groupName: groupName.trim(),
//       desc,
//       owner,
//       members: finalMembers,
//       maxCount,
//       style,
//       inviteNeedConfirm: false,
//     };

//     // Add groupId if provided
//     if (groupId) {
//       groupData.groupId = groupId;
//     }

//     const result = await (chatClient.groupManager.createGroup as any)(groupData);

//     console.log("✅ Agora group created:", result);
//     return result;

//   } catch (e: any) {
//     console.error("❌ Failed to create Agora group:", e);
//     throw new Error(
//       e?.description || e?.message || "Failed to create Agora group"
//     );
//   }
// };

export const createAgoraGroup = async ({
  groupId,
  groupName,
  desc = "",
  owner,
  members = [],
  maxCount = 200,
  style = ChatGroupStyle.PublicOpenJoin,
}: AgoraGroupOptions) => {
  try {
    console.log(`🔄 Creating Agora group:`);
    console.log(`   ID: ${groupId}`);
    console.log(`   Name: ${groupName}`);
    console.log(`   Owner: ${owner}`);
    console.log(`   All Members:`, members);
    console.log(`   Total Members: ${members.length}`);

    // ✅ Filter out duplicates and owner from members list
    // Owner is automatically added, don't include in members array
    const membersWithoutOwner = members
      .filter(id => id !== owner)
      .filter((value, index, self) => self.indexOf(value) === index); // Remove duplicates

    console.log(`   Members to add (excluding owner):`, membersWithoutOwner);

    const groupData: any = {
      groupId: groupId.toString(),
      groupName: groupName.trim(),
      desc: desc || `Chat group: ${groupName}`,
      owner: owner,
      members: membersWithoutOwner, // ✅ Only non-owner members
      maxCount: maxCount,
      style: style,
      inviteNeedConfirm: false,
    };

    const result = await chatClient.groupManager.createGroup(groupData);
    
    console.log("✅ Agora group created:", {
      id: result.groupId,
      name: result.groupName,
      owner: result.owner,
      memberCount: result.memberCount
    });
    
    return result;

  } catch (e: any) {
    console.error("❌ Failed to create Agora group:", e);
    
    if (e?.code === 602) {
      console.log("ℹ️ Group already exists in Agora");
      throw e;
    }
    
    throw new Error(
      e?.description || e?.message || "Failed to create Agora group"
    );
  }
};


// export const createAgoraGroup = async ({
//   groupId, // 🚨 MUST use backend group ID
//   groupName,
//   desc = "",
//   owner,
//   members = [],
//   maxCount = 200,
//   style = ChatGroupStyle.PrivateMemberCanInvite, // Change to this
// }: AgoraGroupOptions) => {
//   try {
//     const finalMembers = members.filter(id => id !== owner);

//     console.log(`🔄 Creating Agora group with ID: ${groupId}`);
//     console.log(`   Group Name: ${groupName}`);
//     console.log(`   Owner: ${owner}`);
//     console.log(`   Members to add: ${finalMembers.length}`);

//     // 🚨 MUST use the backend groupId
//     const groupData: any = {
//       groupId: groupId.toString(), // ✅ Use provided ID
//       groupName: groupName.trim(),
//       desc: desc || `Chat for ${groupName}`,
//       owner,
//       members: finalMembers,
//       maxCount,
//       style,
//       inviteNeedConfirm: false,
//     };

//     const result = await chatClient.groupManager.createGroup(groupData);
    
//     console.log("✅ Agora group created successfully:", {
//       id: result.groupId,
//       name: result.groupName,
//       owner: result.owner,
//       memberCount: result.memberCount
//     });
    
//     // 🚨 IMPORTANT: Add members after group creation
//     if (finalMembers.length > 0) {
//       console.log("👥 Adding members to group...");
//       try {
//         await chatClient.groupManager.addMembers({
//           groupId: groupId.toString(),
//           members: finalMembers
//         });
//         console.log(`✅ Added ${finalMembers.length} members to group`);
//       } catch (addError) {
//         console.warn("⚠️ Could not add members:", addError);
//       }
//     }
    
//     return result;

//   } catch (e: any) {
//     console.error("❌ Failed to create Agora group:", e);
    
//     // If group already exists with same ID, return that
//     if (e?.code === 602) {
//       console.log("ℹ️ Group already exists, fetching info...");
//       try {
//         const existingGroup = await chatClient.groupManager.fetchGroupInfoFromServer(groupId.toString());
//         return existingGroup;
//       } catch (fetchError) {
//         throw e;
//       }
//     }
    
//     throw new Error(
//       e?.description || e?.message || "Failed to create Agora group"
//     );
//   }
// };
// export const createAgoraGroup = async ({
//   groupName,
//   desc = "",
//   owner,
//   members = [],
//   maxCount = 200,
//   style = ChatGroupStyle.PrivateOnlyOwnerInvite,
// }: AgoraGroupOptions) => {
//   try {
//     const finalMembers = members.filter(id => id !== owner);

//     const result = await (chatClient.groupManager.createGroup as any)({
//       groupName: groupName.trim(),
//       desc,
//       owner,
//       members: finalMembers,
//       maxCount,
//       style,
//       inviteNeedConfirm: false,
//     });

//     console.log("✅ Agora group created:", result);
//     return result;

//   } catch (e: any) {
//     console.error("❌ Failed to create Agora group:", e);
//     throw new Error(
//       e?.description || e?.message || "Failed to create Agora group"
//     );
//   }
// };



// export const joinAgoraGroup = async (groupId: string) => {
//   try {
//     const res = await (chatClient.groupManager as any).enterGroup(groupId);
//     console.log("✅ Entered Agora group:", groupId, res);
//     return res;
//   } catch (e: any) {
//     if (
//       e?.description?.includes("already") ||
//       e?.code === 200
//     ) {
//       console.log("ℹ️ Already in group:", groupId);
//       return { success: true };
//     }

//     console.log("❌ enterGroup failed:", e);
//     throw e;
//   }
// };

// Add this function to your services
export const checkGroupInfo = async (groupId: string) => {
  try {
    const groupInfo = await chatClient.groupManager.fetchGroupInfoFromServer(groupId);
    console.log("Group Info:", groupInfo);
    return groupInfo;
  } catch (error) {
    console.error("Error fetching group info:", error);
    return null;
  }
};

export const listJoinedGroups = async () => {
  try {
    const groups = await chatClient.groupManager.getJoinedGroups();
    console.log("Joined groups:", groups);
    return groups;
  } catch (error) {
    console.error("Error listing joined groups:", error);
    return [];
  }
};
export const ensureGroupExists = async (groupId: string, groupName: string, ownerId: string, members: string[] = []) => {
  try {
    console.log(`🔍 Checking if Agora group ${groupId} exists...`);
    
    // Try to fetch group info
    const groupInfo = await chatClient.groupManager.fetchGroupInfoFromServer(groupId);
    console.log(`✅ Group ${groupId} exists in Agora`);
    console.log(`   Name: ${groupInfo.groupName}, Owner: ${groupInfo.owner}`);
    
    return { exists: true, groupInfo };
    
  } catch (error: any) {
    // If error code is 600 (group not found)
    if (error?.code === 600) {
      console.log(`❌ Group ${groupId} NOT FOUND in Agora`);
      console.log(`   Possible reasons:`);
      console.log(`   1. Group was created with different ID`);
      console.log(`   2. Group was not created in Agora`);
      console.log(`   3. Network issue`);
      
      // 🚨 DON'T CREATE NEW GROUP HERE!
      // Let the original creator handle group creation
      console.log(`⚠️ Returning null, group should be created by owner`);
      return { exists: false, groupInfo: null };
    }
    
    console.error(`❌ Error checking group ${groupId}:`, error);
    throw error;
  }
};


// export const ensureGroupExists = async (groupId: string, groupName: string, ownerId: string, members: string[] = []) => {
//   try {
//     console.log(`Checking if group ${groupId} exists in Agora...`);
    
//     // First, try to get group info
//     const groupInfo = await chatClient.groupManager.fetchGroupInfoFromServer(groupId);
//     console.log(`Group ${groupId} already exists in Agora`);
//     return { exists: true, groupInfo };
    
//   } catch (error: any) {
//     // If error code is 600 (group not found), create it
//     if (error?.code === 600) {
//       console.log(`Group ${groupId} not found in Agora, creating it...`);
      
//       try {
//         const result = await createAgoraGroup({
//           groupName: groupName || `Group ${groupId}`,
//           desc: `Chat group for ${groupName}`,
//           owner: ownerId,
//           members: members,
//           maxCount: 200,
//           style: ChatGroupStyle.PrivateOnlyOwnerInvite,
//         });
        
//         console.log(`✅ Group created in Agora:`, result);
//         return { exists: false, created: true, groupInfo: result };
        
//       } catch (createError) {
//         console.error(`❌ Failed to create group ${groupId}:`, createError);
//         throw createError;
//       }
//     }
    
//     throw error;
//   }
// };

// agoraChatServices.ts me joinGroupIfNeeded function ke start me:
export const joinGroupIfNeeded = async (groupId: string) => {
  try {
    // 🔍 DEBUG LOGS
    console.log("=== DEBUG: Checking Agora Methods ===");
    console.log("GroupManager type:", typeof chatClient.groupManager);
    
    // List all available methods
    const allMethods = Object.getOwnPropertyNames(Object.getPrototypeOf(chatClient.groupManager))
      .concat(Object.keys(chatClient.groupManager));
    
    console.log("All groupManager methods:", allMethods);
    
    // Check specific important methods
    const importantMethods = [
      'enterGroup', 'joinGroup', 'applyToJoinGroup', 
      'requestToJoinGroup', 'joinPublicGroup', 'acceptGroupInvitation',
      'getGroupInvitations', 'getJoinedGroups', 'fetchGroupInfoFromServer'
    ];
    
    importantMethods.forEach(method => {
      const exists = typeof (chatClient.groupManager as any)[method] === 'function';
      console.log(`📌 ${method}: ${exists ? '✅ Available' : '❌ Not available'}`);
    });
    
    console.log("======================================");
    
    // Rest of your function...
    const groups = await chatClient.groupManager.getJoinedGroups();
    // ... existing code
  } catch (error) {
    console.error("Error:", error);
    throw error;
  }
};

// Add this function in your file
// Addmember.js में ये function replace करें
export const createAgoraGroupDirectly = async (
  groupId: string, 
  groupName: string, 
  ownerId: string, 
  allMembers: string[]
) => {
  try {
    console.log(`🔄 Creating Agora group directly:`);
    console.log(`   ID: ${groupId}`);
    console.log(`   Name: ${groupName}`);
    console.log(`   Owner: ${ownerId}`);
    console.log(`   All Members: ${allMembers.length}`);
    
    // Filter out owner from members list for Agora
    const membersToAdd = allMembers.filter(member => member !== ownerId);
    console.log(`   Members to add: ${membersToAdd.length}`);
    
    // ✅ FIXED: Use ChatGroupStyle.PublicOpenJoin (3) but with correct parameters
    const groupData = {
      groupId: groupId, // ✅ यही backend group ID use करें
      groupName: groupName.trim(),
      desc: `Group chat for ${groupName}`,
      owner: ownerId,
      members: membersToAdd,
      maxCount: 200,
      style: 0, // ✅ ChatGroupStyle.PrivateOnlyOwnerInvite (0) use करें
      // style: 3, // PublicOpenJoin - agar public chahiye
      inviteNeedConfirm: false,
    };
    
    console.log("📦 Agora Group Data to send:", JSON.stringify(groupData, null, 2));
    
    // ✅ IMPORTANT: Use the CORRECT method to create group
    const result = await chatClient.groupManager.createGroup(groupData);
    
    console.log("✅ Agora group creation response:", JSON.stringify(result, null, 2));
    
    // ✅ Verify the group ID matches
    if (result.groupId !== groupId) {
      console.warn(`⚠️ WARNING: Requested ID ${groupId}, but got ${result.groupId}`);
      console.warn(`   Group will be created with ID: ${result.groupId}`);
    } else {
      console.log(`🎉 SUCCESS: Agora group created with same ID: ${groupId}`);
    }
    
    return result;
  } catch (error: any) {
    console.error("❌ Failed to create Agora group:", error);
    console.error("Error code:", error?.code);
    console.error("Error message:", error?.message);
    console.error("Error description:", error?.description);
    
    // If group already exists
    if (error?.code === 602) {
      console.log(`ℹ️ Agora group ${groupId} already exists`);
      
      // Still try to add members
      try {
        const otherMembers = allMembers.filter(member => member !== ownerId);
        if (otherMembers.length > 0) {
          await chatClient.groupManager.addMembers({
            groupId: groupId,
            members: otherMembers
          });
          console.log(`✅ Added ${otherMembers.length} members to existing group`);
        }
      } catch (addError) {
        console.warn("⚠️ Could not add members:", addError);
      }
      
      return null;
    }
    
    throw error;
  }
};
// export const joinGroupIfNeeded = async (groupId: string) => {
//   try {
//     // 1. Check if already a member
//     const groups = await chatClient.groupManager.getJoinedGroups();
//     const isMember = groups.some(g => g.groupId === groupId);
    
//     if (isMember) {
//       console.log(`✅ Already a member of group ${groupId}`);
//       return { success: true, alreadyMember: true };
//     }
    
//     console.log(`🔄 Trying to join group ${groupId}...`);
    
//     // 2. First check for pending invitations
//     try {
//       const invitations = await chatClient.groupManager.getGroupInvitations();
//       const myInvitation = invitations.find(inv => inv.groupId === groupId);
      
//       if (myInvitation) {
//         await chatClient.groupManager.acceptGroupInvitation(groupId);
//         console.log(`✅ Accepted invitation to ${groupId}`);
//         return { success: true, viaInvitation: true };
//       }
//     } catch (inviteError) {
//       console.log("No pending invitations found");
//     }
    
//     // 3. Try to enter group (for public groups)
//     try {
//       // Check if enterGroup exists
//       if ((chatClient.groupManager as any).enterGroup) {
//         await (chatClient.groupManager as any).enterGroup(groupId);
//         console.log(`✅ Joined group ${groupId} via enterGroup`);
//         return { success: true, viaEnter: true };
//       }
//     } catch (enterError: any) {
//       console.log(`enterGroup failed:`, enterError?.message);
      
//       // If it's a private group error
//       if (enterError?.code === 606 || enterError?.code === 609) {
//         console.log(`📝 Group ${groupId} is private. You need an invitation.`);
        
//         // Show message to user
//         return { 
//           success: false, 
//           error: "PRIVATE_GROUP", 
//           message: "This is a private group. Ask the admin to invite you." 
//         };
//       }
//     }
    
//     // 4. If all fails, return appropriate message
//     console.warn(`⚠️ Could not join group ${groupId}. Possible reasons:`);
//     console.warn(`   - Group is private (need invitation)`);
//     console.warn(`   - Group doesn't exist in Agora`);
//     console.warn(`   - Network/connection issue`);
    
//     return { 
//       success: false, 
//       error: "JOIN_FAILED", 
//       message: "Could not join group. Ask admin to invite you." 
//     };
    
//   } catch (error) {
//     console.error(`❌ Error in joinGroupIfNeeded:`, error);
//     return { 
//       success: false, 
//       error: "EXCEPTION", 
//       message: error.message 
//     };
//   }
// };