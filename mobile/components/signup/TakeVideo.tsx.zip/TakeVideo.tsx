// import { icons } from "@/constants/icons";
// import { CommonFileUpload } from "@/lib/api";
// import { signupProps } from "@/types";
// import { CameraRoll } from "@react-native-camera-roll/camera-roll";
// import { Audio, ResizeMode, Video } from "expo-av";
// import { CameraType, CameraView, useCameraPermissions } from "expo-camera";
// import { useEffect, useRef, useState } from "react";
// import {
//   ActivityIndicator,
//   Alert,
//   Image,
//   PermissionsAndroid,
//   Platform,
//   StatusBar,
//   Text,
//   TouchableOpacity,
//   View,
// } from "react-native";


// const TakeVideo = ({ data, updateData, onNext, error }: signupProps) => {
//   const [facing, setFacing] = useState<CameraType>("front");
//   const [permission, requestPermission] = useCameraPermissions();
//   const [audioPermission, requestAudioPermission] = Audio.usePermissions();
//   const [recordedVideo, setRecordedVideo] = useState<string | null>(null);
//   const [recording, setRecording] = useState(false);
//   const [recordingDuration, setRecordingDuration] = useState(0);
//   const [timerInterval, setTimerInterval] = useState<ReturnType<typeof setInterval> | null>(null);
//   const [cameraReady, setCameraReady] = useState(false);
//   const [permissionsChecked, setPermissionsChecked] = useState(false);
//   const cameraRef = useRef<CameraView>(null);
//   const videoRef = useRef(null);
//   const [loading, setLoading] = useState(false);

//   useEffect(() => {
//     const checkPermissions = async () => {
//       try {
//         const cameraStatus = permission?.granted
//           ? permission
//           : await requestPermission();
//         const audioStatus = audioPermission?.granted
//           ? audioPermission
//           : await requestAudioPermission();

//         console.log("Camera permission:", cameraStatus?.granted);
//         console.log("Audio permission:", audioStatus?.granted);

//         setPermissionsChecked(true);
//       } catch (err) {
//         console.error("Permission check failed:", err);
//         Alert.alert(
//           "Permission Error",
//           "Failed to check camera permissions. Please restart the app."
//         );
//       }
//     };

//     checkPermissions();

//     // Cleanup interval on unmount
//     return () => {
//       if (timerInterval) {
//         clearInterval(timerInterval);
//       }
//     };
//   }, []);

//   const requestAllPermissions = async () => {
//     try {
//       const cameraStatus = await requestPermission();
//       const audioStatus = await requestAudioPermission();

//       console.log("Requested camera permission:", cameraStatus.granted);
//       console.log("Requested audio permission:", audioStatus.granted);

//       return cameraStatus.granted && audioStatus.granted;
//     } catch (err) {
//       console.error("Permission request failed:", err);
//       Alert.alert(
//         "Permission Error",
//         "Failed to request permissions. Please try again."
//       );
//       return false;
//     }
//   };

//   // Handle camera readiness
//   const onCameraReady = () => {
//     console.log("Camera is ready");
//     setCameraReady(true);
//   };

//   // Handle camera errors
//   const onCameraError = (error: any) => {
//     console.error("Camera error:", error);
//     Alert.alert(
//       "Camera Error",
//       "There was a problem with the camera. Please restart the app."
//     );
//   };

//   if (!permissionsChecked) {
//     return (
//       <View className="flex-1 items-center justify-center bg-[#1D2733]">
//         <Text className="text-white">Checking permissions...</Text>
//       </View>
//     );
//   }

//   if (!permission?.granted || !audioPermission?.granted) {
//     return (
//       <>
//         <StatusBar barStyle="light-content" backgroundColor="#1D2733" />
//         <View className="bg-[#1D2733] py-12 flex flex-col items-center justify-center">
//           <Text className="text-2xl text-white text-center mb-2 font-normal">
//             Record Intro Video
//           </Text>
//           <Text className="text-center text-xs text-gray px-14">
//             Record a short intro video to help others get to know you
//           </Text>
//         </View>
//         <View className="flex-1 h-[62vh] items-center justify-center">
//           <Text className="text-center text-lg mb-6">
//             We need your permission to use the camera & Audio
//           </Text>
//           <TouchableOpacity
//             onPress={requestAllPermissions}
//             className="bg-primary px-6 py-3 rounded-lg"
//           >
//             <Text className="text-white font-medium">Grant Permission</Text>
//           </TouchableOpacity>
//         </View>
//       </>
//     );
//   }

//   //code i get from gemini
// // const startRecording = async () => {
// //     console.log("in startRecording");
    
// //     if (!cameraRef.current || !cameraReady) {
// //       Alert.alert("Camera not ready", "Please wait for camera to initialize");
// //       return;
// //     }

// //     try {
// //       setRecording(true);
// //       setRecordingDuration(0);

// //       const interval = setInterval(() => {
// //         setRecordingDuration((prev) => prev + 1);
// //       }, 1000) as unknown as NodeJS.Timeout;
// //       setTimerInterval(interval);

// //       console.log("Starting recording...");

// //       cameraRef.current
// //         .recordAsync({
// //           maxDuration: 30, // Max duration for safety
// //           // quality: Camera.Constants.VideoQuality['720p'] // Optional: Specify quality
// //         })
// //         .then((video) => {
// //           console.log("Recording successfully completed:", video);
// //           if (video && video.uri) {
// //             setRecordedVideo(video.uri);
// //           }
// //         })
// //         .catch((err) => {
// //           console.error("Recording error:", err);
// //           Alert.alert(
// //             "Recording Error",
// //             "Failed to record video. Please try again."
// //           );
// //           // Manually stop recording state and timer on failure
// //           setRecording(false);
// //           if (timerInterval) clearInterval(timerInterval); 
// //         });

// //     } catch (error) {
// //       console.error("Failed to initiate recording:", error);
// //       Alert.alert("Error", "Failed to start recording. Please try again.");
// //       setRecording(false);
// //       if (timerInterval) clearInterval(timerInterval);
// //     } 
// //   };

// //code i get from chatgpt
// const startRecording = async () => {
//   if (!cameraRef.current || !cameraReady) {
//     Alert.alert("Camera not ready", "Please wait for camera to initialize");
//     return;
//   }

//   // Declare interval variable OUTSIDE try so it can be used in finally
//   let interval: ReturnType<typeof setInterval> | null = null;

//   try {
//     setRecording(true);
//     setRecordingDuration(0);

//     // Correct interval type for React Native
//     interval = setInterval(() => {
//       setRecordingDuration(prev => prev + 1);
//     }, 1000);

//     setTimerInterval(interval);

//     console.log("Starting recording...");

//     const video = await cameraRef.current.recordAsync();

//     console.log("Recording finished:", video?.uri);

//     if (video?.uri) {
//       setRecordedVideo(video.uri);

//         // 🔥 ADD THIS
//         setTimeout(() => {
//           videoRef.current?.play();
//         }, 300);
//     }

//   } catch (error) {
//     console.log("Recording error", error);
//     Alert.alert("Error", "Failed to record");

//   } finally {
//     setRecording(false);

//     // Cleanup interval safely
//     if (interval) {
//       clearInterval(interval);
//     }
//   }
// };


//   //code that previously written here
//   // const startRecording = async () => {
//   //   console.log("in startRecording");
    
//   //   if (!cameraRef.current || !cameraReady) {
//   //     Alert.alert("Camera not ready", "Please wait for camera to initialize");
//   //     return;
//   //   }

//   //   try {
//   //     setRecording(true);
//   //     setRecordingDuration(0);

//   //     // Start the timer
//   //     const interval = setInterval(() => {
//   //       setRecordingDuration((prev) => prev + 1);
//   //     }, 1000) as unknown as NodeJS.Timeout;
//   //     setTimerInterval(interval);

//   //     console.log("Starting recording...");

//   //     // Start recording with more explicit error handling
//   //     const video = await cameraRef.current
//   //       .recordAsync({
//   //         maxDuration: 30,
//   //       })
//   //       .catch((err) => {
//   //         console.error("Recording error:", err);
//   //         Alert.alert(
//   //           "Recording Error",
//   //           "Failed to record video. Please try again."
//   //         );
//   //         throw err;
//   //       });

//   //     console.log("Recording completed:", video);

//   //     if (video) {
//   //       setRecordedVideo(video?.uri);
//   //     }
//   //   } catch (error) {
//   //     console.error("Failed to record video:", error);
//   //     Alert.alert("Error", "Failed to record video. Please try again.");
//   //   } 
//   //   finally {
//   //     if (timerInterval) clearInterval(timerInterval);
//   //   }
//   // };

//     const toggleCameraFacing = () => {
//       setFacing((current) => (current === "back" ? "front" : "back"));
//     };
  
//     const requestGalleryPermission = async () => {
//       if (Platform.OS === "android") {
//         const granted = await PermissionsAndroid.request(
//           PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
//           {
//             title: "Storage Permission",
//             message: "App needs access to your storage to save photos",
//             buttonNeutral: "Ask Me Later",
//             buttonNegative: "Cancel",
//             buttonPositive: "OK",
//           }
//         );
//         return granted === PermissionsAndroid.RESULTS.GRANTED;
//       }
//       return true; // iOS handles via Info.plist automatically
//     };


//   // const stopRecording = async() => {
//   //   if (!recording) return;

//   //   try {
//   //     if (cameraRef.current) {
//   //       console.log("Stopping recording...");
//   //       cameraRef.current.stopRecording();

//   //     }
//   //   } catch (err) {
//   //     console.error("Error stopping recording:", err);
//   //   }

//   //   setRecording(false);

//   //   // Clear the timer
//   //   if (timerInterval) {
//   //     clearInterval(timerInterval);
//   //     setTimerInterval(null);
//   //   }
//   // }

//   const stopRecording = () => {
//   if (!recording) return;

//   try {
//     cameraRef.current?.stopRecording();
//     console.log("Stopping recording...");
//   } catch (e) {
//     console.log("Stop error:", e);
//   }

//   setRecording(false);
//   if (timerInterval) {
//     clearInterval(timerInterval);
//     setTimerInterval(null);
//   }
// };


//   //old code of async
//   // const handleSaveVideo = async () => {
//   //   if (!recordedVideo) return;
  
//   //   setLoading(true);
  
//   //   try {
//   //     console.log("Saving video locally:", recordedVideo);
  
//   //     // 1. Save video URI to AsyncStorage
//   //     await AsyncStorage.setItem("localUserVideo", recordedVideo);
//   //     console.log("Saved video URI to AsyncStorage");
  
//   //     // 2. Save video to phone gallery
//   //     const hasPermission = await requestGalleryPermission();
  
//   //     if (hasPermission) {
//   //       await CameraRoll.save(recordedVideo, { type: "video" });
//   //       console.log("Video saved to gallery!");
//   //     } else {
//   //       console.warn("Gallery permission denied");
//   //     }
  
//   //     Alert.alert(
//   //       "Saved Successfully",
//   //       "Your video has been uploaded successfully."
//   //     );
  
//   //     // Move to next screen
//   //     onNext();
  
//   //   } catch (error) {
//   //     console.error("Error saving video:", error);
//   //     Alert.alert("Error", "Failed to save video. Please try again.");
  
//   //   } finally {
//   //     setLoading(false);
//   //   }
//   // };
  

//   const handleSaveVideo = async () => {
//     if (recordedVideo) {
//       setLoading(true);
//       try {
//         console.log("Preparing to upload video:", recordedVideo);


//       // --- SAVE TO GALLERY ---
//       const hasPermission = await requestGalleryPermission();
//       if (hasPermission) {
//         await CameraRoll.save(recordedVideo, { type: "video" });
//         console.log("Video saved to gallery!");
//       } else {
//         console.warn("Gallery permission denied");
//       }


//         // Create FormData object
//         const formData = new FormData();

//         // Create file object from video URI
//         const fileUri = recordedVideo;
//         const fileName = fileUri.split("/").pop();
//         const fileType = "video/mp4";

//         // Append file to FormData with the key 'uploadattachments[]'
//         formData.append("uploadattachments[]", {
//           uri: fileUri,
//           name: fileName,
//           type: fileType,
//         } as any);

//         console.log("Uploading video...");

//         // Call the upload API with FormData
//         const res = await CommonFileUpload(formData);
//         console.log("Video upload response:", res);

//         if (res && res?.name) {
//           updateData({ liveVideo: res?.name });
//           Alert.alert(
//             "Upload Successful",
//             "Your video has been successfully uploaded."
//           );
//           console.log("Updated video data with:", res?.name);
//           onNext();
//         } else {
//           console.error("Upload response missing name property:", res);
//           Alert.alert(
//             "Upload Failed",
//             "There was an issue uploading your video. Please try again."
//           );
//         }
//       } catch (error) {
//         console.error("Failed to upload video:", error);
//         Alert.alert(
//           "Upload Failed",
//           "There was an issue uploading your video. Please try again."
//         );
//       } finally {
//         setLoading(false);
//       }
//     }
//   };

//   const retakeVideo = () => {
//     setRecordedVideo(null);
//   };

//   const formatDuration = (seconds: number) => {
//     const mins = Math.floor(seconds / 60);
//     const secs = seconds % 60;
//     return `${mins < 10 ? "0" : ""}${mins}:${secs < 10 ? "0" : ""}${secs}`;
//   };

//   return (
//     <View className="flex-1 bg-black">
//       {recordedVideo ? (
//         // Video preview mode
//         <>
//           <StatusBar barStyle="light-content" backgroundColor="#1D2733" />
//           <View className="bg-[#1D2733] py-12 flex flex-col items-center justify-center">
//             <Text className="text-2xl text-white text-center mb-2 font-normal">
//               Preview Your Video
//             </Text>
//             <Text className="text-center text-xs text-gray px-14">
//               Does this look good? You can retake if needed
//             </Text>
//             <TouchableOpacity onPress={onNext} className="absolute top-16 right-4">
//               <Text className="text-white text-sm font-semibold">
//                 Skip
//               </Text>
//             </TouchableOpacity>
//           </View>
//           <View className="flex-1 h-[62vh] bg-black">
//           {/* <VideoView
//               ref={videoRef}
//               style={{ flex: 1 }}
//               video={{ uri: recordedVideo }}
//               showsControls={true}
//               isLooping={false}
//               resizeMode="contain"
//             /> */}
//             <Video
//               ref={videoRef}
//               source={{ uri: recordedVideo }}
//               resizeMode={ResizeMode.CONTAIN}
//               useNativeControls
//               isLooping
//               shouldPlay
//               style={{ flex: 1 }}
//             />
//           </View>
//           <View className="bg-[#1D2733] h-[18vh] py-12 flex flex-row items-center justify-between gap-4 px-8">
//             <TouchableOpacity
//               onPress={retakeVideo}
//               className="bg-white/20 px-6 py-3 rounded-full flex-1"
//             >
//               <Text className="text-white font-semibold text-center">
//                 Retake
//               </Text>
//             </TouchableOpacity>
//             <TouchableOpacity
//               onPress={handleSaveVideo}
//               className="bg-primary px-6 py-3 rounded-full flex-1"
//             >
//               {loading ? (
//                 <ActivityIndicator size="small" color="#fff" />
//               ) : (
//                 <Text className="text-white font-semibold text-center">
//                   Use Video
//                 </Text>
//               )}
//             </TouchableOpacity>
//           </View>
//         </>
//       ) : (
//         // Camera recording mode
//         <>
//           <StatusBar barStyle="light-content" backgroundColor="#1D2733" />
//           <View className="bg-[#1D2733] py-8 flex flex-col items-center justify-center">
//             <Text className="text-xl text-white text-center mb-2 font-normal" style={{paddingTop: Platform.OS === 'ios' ? 30: 30}}>
//               Upload Live Video
//             </Text>
//             <Text className="text-center text-xs text-gray px-14">
//               Upload 6-8 pictures plus 1 picture or video has to be taken on the
//               app with date stamp
//             </Text>
//             <TouchableOpacity onPress={onNext} className="absolute top-16 right-4">
//               <Text className="text-white text-sm font-semibold">
//                 Skip
//               </Text>
//             </TouchableOpacity>
//           </View>
//           <CameraView
//             className="flex-1"
//             facing={facing}
//             ref={cameraRef}
//             mode="video"
//             onCameraReady={onCameraReady}
//             onMountError={onCameraError}
//             zoom={0}
//           >
//             <View className="h-[62vh] flex-1 bg-transparent">
//               {/* {recording && (
//                 <View className="absolute top-4 left-0 right-0 flex-row justify-center items-center">
//                   <View className="px-4 py-2 bg-black/50 rounded-full flex-row items-center">
//                     <View className="w-3 h-3 rounded-full bg-red-500 mr-2 animate-pulse" />
//                     <Text className="text-white font-medium">
//                       {formatDuration(recordingDuration)}
//                     </Text>
//                   </View>
//                 </View>
//               )} */}
//             </View>
//             <View className="absolute top-4 left-0 right-0 flex-row justify-center items-center">
//               <View className="px-4 py-2 bg-black/50 rounded-full flex-row items-center">
//                 <View className="w-3 h-3 rounded-full bg-red-500 mr-2 animate-pulse" />
//                 <Text className="text-white font-medium">
//                   {formatDuration(recordingDuration)}
//                 </Text>
//               </View>
//             </View>
//           </CameraView>
//           <View className="bg-[#1D2733] py-12 flex flex-row items-center justify-between px-8">
//             <TouchableOpacity
//               className="w-14 h-14 rounded-full bg-black/30 items-center justify-center"
//               onPress={toggleCameraFacing}
//               disabled={recording || !cameraReady}
//             >
//               <Image source={icons.flip} className="w-8 h-8" />
//             </TouchableOpacity>

//             {recording ? (
//               <>
//                 <TouchableOpacity
//                   className="w-20 h-20 rounded-full border-4 border-red-500 items-center justify-center"
//                   onPress={stopRecording}
//                 >
//                   <View className="w-8 h-8 rounded-lg bg-red-500"></View>
//                 </TouchableOpacity>
//               </>
//             ) : (
//               // Start recording button
//               <TouchableOpacity
//                 className="w-20 h-20 rounded-full border-4 border-white items-center justify-center"
//                 onPress={startRecording}
//                 disabled={!cameraReady}
//               >
//                 <View className="w-16 h-16 rounded-full bg-red-500 opacity-90"></View>
//               </TouchableOpacity>
//             )}

//             <View className="w-14 h-14" />
//           </View>
//         </>
//       )}
//     </View>
//   );
// };

// export default TakeVideo;


import { icons } from "@/constants/icons";
import { CommonFileUpload } from "@/lib/api";
import { signupProps } from "@/types";
import { CameraRoll } from "@react-native-camera-roll/camera-roll";
import { Audio, ResizeMode, Video } from "expo-av";
import { CameraType, CameraView, useCameraPermissions } from "expo-camera";
import * as FileSystem from "expo-file-system";
import React, { useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Image,
  PermissionsAndroid,
  Platform,
  StatusBar,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

const TakeVideo = ({ data, updateData, onNext, error }: signupProps) => {
  const [facing, setFacing] = useState<CameraType>("front");
  const [permission, requestPermission] = useCameraPermissions();
  const [audioPermission, requestAudioPermission] = Audio.usePermissions();
  const [recordedVideo, setRecordedVideo] = useState<string | null>(null);
  const [recording, setRecording] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [cameraReady, setCameraReady] = useState(false);
  const [permissionsChecked, setPermissionsChecked] = useState(false);
  const cameraRef = useRef<CameraView | null>(null);
  const videoRef = useRef<any>(null);
  const [loading, setLoading] = useState(false);

  // store interval id in a ref to avoid stale closures
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    let mounted = true;

    const checkPermissions = async () => {
      try {
        const cameraStatus = permission?.granted
          ? permission
          : await requestPermission();
        const audioStatus = audioPermission?.granted
          ? audioPermission
          : await requestAudioPermission();

        console.log("Camera permission:", cameraStatus?.granted);
        console.log("Audio permission:", audioStatus?.granted);

        if (mounted) setPermissionsChecked(true);
      } catch (err) {
        console.error("Permission check failed:", err);
        Alert.alert(
          "Permission Error",
          "Failed to check camera permissions. Please restart the app."
        );
      }
    };

    checkPermissions();

    return () => {
      mounted = false;
      // ensure interval cleanup
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    };
  }, []);

  const requestAllPermissions = async () => {
    try {
      const cameraStatus = await requestPermission();
      const audioStatus = await requestAudioPermission();

      console.log("Requested camera permission:", cameraStatus.granted);
      console.log("Requested audio permission:", audioStatus.granted);

      return cameraStatus.granted && audioStatus.granted;
    } catch (err) {
      console.error("Permission request failed:", err);
      Alert.alert(
        "Permission Error",
        "Failed to request permissions. Please try again."
      );
      return false;
    }
  };

  const onCameraReady = () => {
    console.log("Camera is ready");
    setCameraReady(true);
  };

  const onCameraError = (error: any) => {
    console.error("Camera error:", error);
    Alert.alert(
      "Camera Error",
      "There was a problem with the camera. Please restart the app."
    );
  };

  // Helper: get file extension and mime type fallback
  const getMimeTypeFromUri = (uri: string) => {
    try {
      const parts = uri.split(".");
      const ext = parts[parts.length - 1].toLowerCase();
      switch (ext) {
        case "mp4":
          return "video/mp4";
        case "mov":
          return "video/quicktime";
        case "3gp":
        case "3gpp":
          return "video/3gpp";
        case "mkv":
          return "video/x-matroska";
        case "webm":
          return "video/webm";
        default:
          return "video/mp4";
      }
    } catch {
      return "video/mp4";
    }
  };

  /**
   * Normalize URI:
   * - On some Samsung devices recorded video returns content:// uri.
   * - Try FileSystem.copyAsync to copy content:// to cacheDirectory and return new file path.
   * - If copy fails, fallback to the original uri.
   */
  const normalizeUri = async (uri: string) => {
    if (!uri) return uri;
    if (!uri.startsWith("content://")) return uri;

    try {
      const dest = `${FileSystem.cacheDirectory}video_${Date.now()}.mp4`;
      console.log("Attempting to copy content:// URI to cache:", uri, "->", dest);
      await FileSystem.copyAsync({ from: uri, to: dest });
      // verify file exists
      const info = await FileSystem.getInfoAsync(dest);
      if (info.exists) {
        console.log("Copied content:// to:", dest);
        return dest;
      } else {
        console.warn("Copied file does not exist after copyAsync. Falling back to original URI.");
        return uri;
      }
    } catch (copyErr) {
      console.warn("Failed to copy content:// URI using FileSystem.copyAsync():", copyErr);
      // fallback: try to use the original uri (some servers accept content:// if RN fetch can read it)
      return uri;
    }
  };

  const toggleCameraFacing = () => {
    setFacing((current) => (current === "back" ? "front" : "back"));
  };

  const requestGalleryPermission = async () => {
    // We no longer request WRITE_EXTERNAL_STORAGE; CameraRoll.save will handle scoped-storage on modern Android.
    // On Android, CameraRoll may still require READ/WRITE for older devices. We keep a pragmatic check.
    if (Platform.OS === "android" && Platform.Version < 29) {
      // for older Android versions you might need WRITE permission (rare)
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
        {
          title: "Storage Permission",
          message: "App needs access to your storage to save videos",
          buttonNeutral: "Ask Me Later",
          buttonNegative: "Cancel",
          buttonPositive: "OK",
        }
      );
      return granted === PermissionsAndroid.RESULTS.GRANTED;
    }
    return true;
  };

  const startRecording = async () => {
    console.log("in startRecording");

    if (!cameraRef.current || !cameraReady) {
      Alert.alert("Camera not ready", "Please wait for camera to initialize");
      return;
    }

    try {
      setRecording(true);
      setRecordingDuration(0);

      // Start the timer (store id in ref)
      timerRef.current = setInterval(() => {
        setRecordingDuration((prev) => prev + 1);
      }, 1000) as unknown as number;

      console.log("Starting recording...");

      // recordAsync is supported on expo-camera's CameraView wrapper; keep maxDuration
      const video = await cameraRef.current.recordAsync({
        maxDuration: 30,
      });

      console.log("Recording completed:", video);

      if (video && video.uri) {
        setRecordedVideo(video.uri);
      } else {
        console.warn("recordAsync returned no uri:", video);
      }
    } catch (error) {
      console.error("Failed to record video:", error);
      Alert.alert("Error", "Failed to record video. Please try again.");
    } finally {
      // stop timer
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
      setRecording(false);
    }
  };

  const stopRecording = async () => {
    if (!recording) return;

    try {
      if (cameraRef.current) {
        console.log("Stopping recording...");
        cameraRef.current.stopRecording();
      }
    } catch (err) {
      console.error("Error stopping recording:", err);
    }

    // ensure timer cleared here as well
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    setRecording(false);
  };

  const handleSaveVideo = async () => {
    if (!recordedVideo) return;

    setLoading(true);
    try {
      console.log("Preparing to upload video:", recordedVideo);

      // --- SAVE TO GALLERY (optional) ---
      const hasPermission = await requestGalleryPermission();
      if (hasPermission) {
        try {
          await CameraRoll.save(recordedVideo, { type: "video" });
          console.log("Video saved to gallery!");
        } catch (saveErr) {
          console.warn("CameraRoll.save failed:", saveErr);
        }
      } else {
        console.warn("Gallery permission denied");
      }

      // Normalize URI (handle content:// on Samsung)
      const fileUri = await normalizeUri(recordedVideo);
      console.log("Upload fileUri after normalization:", fileUri);

      // Extract filename and mime type
      const fileName = fileUri.split("/").pop() || `video_${Date.now()}.mp4`;
      const fileType = getMimeTypeFromUri(fileName);

      // Build FormData
      const formData = new FormData();
      // For android content URIs, using the normalized cache path helps.
      formData.append("uploadattachments[]", {
        uri: fileUri,
        name: fileName,
        type: fileType,
      } as any);

      console.log("Uploading video...");
      const res = await CommonFileUpload(formData);
      console.log("Video upload response:", res);

      if (res && res?.name) {
        updateData({ liveVideo: res?.name });
        Alert.alert("Upload Successful", "Your video has been successfully uploaded.");
        console.log("Updated video data with:", res?.name);
        onNext();
      } else {
        console.error("Upload response missing name property:", res);
        Alert.alert("Upload Failed", "There was an issue uploading your video. Please try again.");
      }
    } catch (error) {
      console.error("Failed to upload video:", error);
      Alert.alert("Upload Failed", "There was an issue uploading your video. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const retakeVideo = () => {
    setRecordedVideo(null);
    setRecordingDuration(0);
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins < 10 ? "0" : ""}${mins}:${secs < 10 ? "0" : ""}${secs}`;
  };

  if (!permissionsChecked) {
    return (
      <View className="flex-1 items-center justify-center bg-[#1D2733]">
        <Text className="text-white">Checking permissions...</Text>
      </View>
    );
  }

  if (!permission?.granted || !audioPermission?.granted) {
    return (
      <>
        <StatusBar barStyle="light-content" backgroundColor="#1D2733" />
        <View className="bg-[#1D2733] py-12 flex flex-col items-center justify-center">
          <Text className="text-2xl text-white text-center mb-2 font-normal">
            Record Intro Video
          </Text>
          <Text className="text-center text-xs text-gray px-14">
            Record a short intro video to help others get to know you
          </Text>
        </View>
        <View className="flex-1 h-[62vh] items-center justify-center">
          <Text className="text-center text-lg mb-6">
            We need your permission to use the camera & Audio
          </Text>
          <TouchableOpacity
            onPress={requestAllPermissions}
            className="bg-primary px-6 py-3 rounded-lg"
          >
            <Text className="text-white font-medium">Grant Permission</Text>
          </TouchableOpacity>
        </View>
      </>
    );
  }

  return (
    <View className="flex-1 bg-black">
      {recordedVideo ? (
        // Preview mode
        <>
          <StatusBar barStyle="light-content" backgroundColor="#1D2733" />
          <View className="bg-[#1D2733] py-12 flex flex-col items-center justify-center">
            <Text className="text-2xl text-white text-center mb-2 font-normal">Preview Your Video</Text>
            <Text className="text-center text-xs text-gray px-14">Does this look good? You can retake if needed</Text>
            <TouchableOpacity onPress={onNext} className="absolute top-16 right-4">
              <Text className="text-white text-sm font-semibold">Skip</Text>
            </TouchableOpacity>
          </View>
          <View className="flex-1 h-[62vh] bg-black">
            <Video
              ref={videoRef}
              source={{ uri: recordedVideo }}
              resizeMode={ResizeMode.CONTAIN}
              useNativeControls
              isLooping
              shouldPlay
              style={{ flex: 1 }}
            />
          </View>
          <View className="bg-[#1D2733] h-[18vh] py-12 flex flex-row items-center justify-between gap-4 px-8">
            <TouchableOpacity onPress={retakeVideo} className="bg-white/20 px-6 py-3 rounded-full flex-1">
              <Text className="text-white font-semibold text-center">Retake</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={handleSaveVideo} className="bg-primary px-6 py-3 rounded-full flex-1">
              {loading ? <ActivityIndicator size="small" color="#fff" /> : <Text className="text-white font-semibold text-center">Use Video</Text>}
            </TouchableOpacity>
          </View>
        </>
      ) : (
        // Camera mode
        <>
          <StatusBar barStyle="light-content" backgroundColor="#1D2733" />
          <View className="bg-[#1D2733] py-8 flex flex-col items-center justify-center">
            <Text className="text-xl text-white text-center mb-2 font-normal" style={{ paddingTop: Platform.OS === "ios" ? 30 : 30 }}>
              Upload Live Video
            </Text>
            <Text className="text-center text-xs text-gray px-14">
              Upload 6-8 pictures plus 1 picture or video has to be taken on the app with date stamp
            </Text>
            <TouchableOpacity onPress={onNext} className="absolute top-16 right-4">
              <Text className="text-white text-sm font-semibold">Skip</Text>
            </TouchableOpacity>
          </View>

          <CameraView
            className="flex-1"
            facing={facing}
            ref={cameraRef}
            mode="video"
            onCameraReady={onCameraReady}
            onMountError={onCameraError}
            zoom={0}
            // Keep properties minimal for compatibility. If using Camera (not CameraView) you can set videoQuality, stabilization etc.
          >
            <View className="h-[62vh] flex-1 bg-transparent">
              {/* Live timer overlay */}
            </View>

            <View className="absolute top-4 left-0 right-0 flex-row justify-center items-center">
              <View className="px-4 py-2 bg-black/50 rounded-full flex-row items-center">
                <View className="w-3 h-3 rounded-full bg-red-500 mr-2 animate-pulse" />
                <Text className="text-white font-medium">{formatDuration(recordingDuration)}</Text>
              </View>
            </View>
          </CameraView>

          <View className="bg-[#1D2733] py-12 flex flex-row items-center justify-between px-8">
            <TouchableOpacity
              className="w-14 h-14 rounded-full bg-black/30 items-center justify-center"
              onPress={toggleCameraFacing}
              disabled={recording || !cameraReady}
            >
              <Image source={icons.flip} className="w-8 h-8" />
            </TouchableOpacity>

            {recording ? (
              <TouchableOpacity className="w-20 h-20 rounded-full border-4 border-red-500 items-center justify-center" onPress={stopRecording}>
                <View className="w-8 h-8 rounded-lg bg-red-500"></View>
              </TouchableOpacity>
            ) : (
              <TouchableOpacity
                className="w-20 h-20 rounded-full border-4 border-white items-center justify-center"
                onPress={startRecording}
                disabled={!cameraReady}
              >
                <View className="w-16 h-16 rounded-full bg-red-500 opacity-90"></View>
              </TouchableOpacity>
            )}

            <View className="w-14 h-14" />
          </View>
        </>
      )}
    </View>
  );
};

export default TakeVideo;
